/* This file has been automatically generated from "cast.list" */

/*
----------------------------------------------------------------------
_svmf_cast_CONSTANT_Class
----------------------------------------------------------------------
*/

inline static _svmt_CONSTANT_Class_info *
_svmf_cast_CONSTANT_Class (_svmt_cp_info * expr)
{
  return (_svmt_CONSTANT_Class_info *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_CONSTANT_Double
----------------------------------------------------------------------
*/

inline static _svmt_CONSTANT_Double_info *
_svmf_cast_CONSTANT_Double (_svmt_cp_info * expr)
{
  return (_svmt_CONSTANT_Double_info *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_CONSTANT_Fieldref
----------------------------------------------------------------------
*/

inline static _svmt_CONSTANT_Fieldref_info *
_svmf_cast_CONSTANT_Fieldref (_svmt_cp_info * expr)
{
  return (_svmt_CONSTANT_Fieldref_info *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_CONSTANT_Float
----------------------------------------------------------------------
*/

inline static _svmt_CONSTANT_Float_info *
_svmf_cast_CONSTANT_Float (_svmt_cp_info * expr)
{
  return (_svmt_CONSTANT_Float_info *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_CONSTANT_Integer
----------------------------------------------------------------------
*/

inline static _svmt_CONSTANT_Integer_info *
_svmf_cast_CONSTANT_Integer (_svmt_cp_info * expr)
{
  return (_svmt_CONSTANT_Integer_info *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_CONSTANT_InterfaceMethodref
----------------------------------------------------------------------
*/

inline static _svmt_CONSTANT_InterfaceMethodref_info *
_svmf_cast_CONSTANT_InterfaceMethodref (_svmt_cp_info * expr)
{
  return (_svmt_CONSTANT_InterfaceMethodref_info *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_CONSTANT_Long
----------------------------------------------------------------------
*/

inline static _svmt_CONSTANT_Long_info *
_svmf_cast_CONSTANT_Long (_svmt_cp_info * expr)
{
  return (_svmt_CONSTANT_Long_info *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_CONSTANT_Methodref
----------------------------------------------------------------------
*/

inline static _svmt_CONSTANT_Methodref_info *
_svmf_cast_CONSTANT_Methodref (_svmt_cp_info * expr)
{
  return (_svmt_CONSTANT_Methodref_info *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_CONSTANT_String
----------------------------------------------------------------------
*/

inline static _svmt_CONSTANT_String_info *
_svmf_cast_CONSTANT_String (_svmt_cp_info * expr)
{
  return (_svmt_CONSTANT_String_info *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_ConstantValue
----------------------------------------------------------------------
*/

inline static _svmt_ConstantValue_attribute *
_svmf_cast_ConstantValue (_svmt_attribute_info * expr)
{
  return (_svmt_ConstantValue_attribute *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_InnerClasses_attribute
----------------------------------------------------------------------
*/

inline static _svmt_InnerClasses_attribute *
_svmf_cast_InnerClasses_attribute (_svmt_attribute_info * expr)
{
  return (_svmt_InnerClasses_attribute *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_LineNumberTable_attribute
----------------------------------------------------------------------
*/

inline static _svmt_LineNumberTable_attribute *
_svmf_cast_LineNumberTable_attribute (_svmt_attribute_info * expr)
{
  return (_svmt_LineNumberTable_attribute *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_array
----------------------------------------------------------------------
*/

inline static _svmt_array_info *
_svmf_cast_array (_svmt_type_info * expr)
{
  return (_svmt_array_info *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_class
----------------------------------------------------------------------
*/

inline static _svmt_class_info *
_svmf_cast_class (_svmt_type_info * expr)
{
  return (_svmt_class_info *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_code_attribute
----------------------------------------------------------------------
*/

inline static _svmt_Code_attribute *
_svmf_cast_code_attribute (_svmt_attribute_info * expr)
{
  return (_svmt_Code_attribute *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_Exceptions_attribute
----------------------------------------------------------------------
*/

inline static _svmt_Exceptions_attribute *
_svmf_cast_Exceptions_attribute (_svmt_attribute_info * expr)
{
  return (_svmt_Exceptions_attribute *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_SourceFile_attribute
----------------------------------------------------------------------
*/

inline static _svmt_SourceFile_attribute *
_svmf_cast_SourceFile_attribute (_svmt_attribute_info * expr)
{
  return (_svmt_SourceFile_attribute *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_jarray
----------------------------------------------------------------------
*/

inline static jarray
_svmf_cast_jarray (jobject expr)
{
  return (jarray) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_jobject
----------------------------------------------------------------------
*/

inline static jobject
_svmf_cast_jobject (jarray expr)
{
  return (jobject) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_jobject_nref
----------------------------------------------------------------------
*/

inline static jobject
_svmf_cast_jobject_nref (_svmt_native_ref * expr)
{
  return (jobject) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_nref_jobject
----------------------------------------------------------------------
*/

inline static _svmt_native_ref *
_svmf_cast_nref_jobject (jobject expr)
{
  return (_svmt_native_ref *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_object_instance
----------------------------------------------------------------------
*/

inline static _svmt_object_instance *
_svmf_cast_object_instance (_svmt_array_instance * expr)
{
  return (_svmt_object_instance *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_array_instance
----------------------------------------------------------------------
*/

inline static _svmt_array_instance *
_svmf_cast_array_instance (_svmt_object_instance * expr)
{
  return (_svmt_array_instance *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_JavaVM
----------------------------------------------------------------------
*/

inline static JavaVM *
_svmf_cast_JavaVM (_svmt_JavaVM * expr)
{
  return (JavaVM *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_parray
----------------------------------------------------------------------
*/

inline static _svmt_array_info **
_svmf_cast_parray (_svmt_type_info ** expr)
{
  return (_svmt_array_info **) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_pclass
----------------------------------------------------------------------
*/

inline static _svmt_class_info **
_svmf_cast_pclass (_svmt_type_info ** expr)
{
  return (_svmt_class_info **) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_type_array
----------------------------------------------------------------------
*/

inline static _svmt_type_info *
_svmf_cast_type_array (_svmt_array_info * expr)
{
  return (_svmt_type_info *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_type_class
----------------------------------------------------------------------
*/

inline static _svmt_type_info *
_svmf_cast_type_class (_svmt_class_info * expr)
{
  return (_svmt_type_info *) (void *) expr;
}


/*
----------------------------------------------------------------------
_svmf_cast_svmt_JNIEnv
----------------------------------------------------------------------
*/

inline static _svmt_JNIEnv *
_svmf_cast_svmt_JNIEnv (JNIEnv * expr)
{
  return (_svmt_JNIEnv *) (void *) expr;
}

