/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * This source file is part of SableVM.                            *
 *                                                                 *
 * See the file "LICENSE" for the copyright information and for    *
 * the terms and conditions for copying, distribution and          *
 * modification of this source file.                               *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef SVM_NATIVE_INTERFACE_H
#define SVM_NATIVE_INTERFACE_H

static const JNINativeInterface _svmv_native_interface;

#endif /* not SVM_NATIVE_INTERFACE_H */
