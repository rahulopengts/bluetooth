/* This file has been automatically generated from "cl_alloc.list" */

/*
----------------------------------------------------------------------
_svmh_cl_zalloc_CONSTANT_Class_info
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_CONSTANT_Class_info (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_Class_info ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_CONSTANT_Class_info), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_CONSTANT_Class_info
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_CONSTANT_Class_info (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_Class_info ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_CONSTANT_Class_info), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_CONSTANT_Double_info
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_CONSTANT_Double_info (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_Double_info ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_CONSTANT_Double_info), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_CONSTANT_Double_info
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_CONSTANT_Double_info (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_Double_info ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_CONSTANT_Double_info), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_CONSTANT_Fieldref_info
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_CONSTANT_Fieldref_info (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_Fieldref_info ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_CONSTANT_Fieldref_info), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_CONSTANT_Fieldref_info
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_CONSTANT_Fieldref_info (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_Fieldref_info ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_CONSTANT_Fieldref_info), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_CONSTANT_Float_info
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_CONSTANT_Float_info (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_Float_info ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_CONSTANT_Float_info), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_CONSTANT_Float_info
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_CONSTANT_Float_info (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_Float_info ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_CONSTANT_Float_info), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_CONSTANT_Integer_info
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_CONSTANT_Integer_info (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_Integer_info ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_CONSTANT_Integer_info), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_CONSTANT_Integer_info
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_CONSTANT_Integer_info (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_Integer_info ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_CONSTANT_Integer_info), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_CONSTANT_InterfaceMethodref_info
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_CONSTANT_InterfaceMethodref_info (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_InterfaceMethodref_info ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_CONSTANT_InterfaceMethodref_info), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_CONSTANT_InterfaceMethodref_info
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_CONSTANT_InterfaceMethodref_info (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_InterfaceMethodref_info ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_CONSTANT_InterfaceMethodref_info), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_CONSTANT_Long_info
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_CONSTANT_Long_info (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_Long_info ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_CONSTANT_Long_info), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_CONSTANT_Long_info
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_CONSTANT_Long_info (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_Long_info ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_CONSTANT_Long_info), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_CONSTANT_Methodref_info
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_CONSTANT_Methodref_info (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_Methodref_info ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_CONSTANT_Methodref_info), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_CONSTANT_Methodref_info
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_CONSTANT_Methodref_info (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_Methodref_info ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_CONSTANT_Methodref_info), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_CONSTANT_NameAndType_info
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_CONSTANT_NameAndType_info (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_NameAndType_info ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_CONSTANT_NameAndType_info), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_CONSTANT_NameAndType_info
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_CONSTANT_NameAndType_info (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_NameAndType_info ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_CONSTANT_NameAndType_info), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_CONSTANT_String_info
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_CONSTANT_String_info (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_String_info ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_CONSTANT_String_info), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_CONSTANT_String_info
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_CONSTANT_String_info (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_String_info ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_CONSTANT_String_info), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_CONSTANT_Utf8_info
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_CONSTANT_Utf8_info (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_Utf8_info ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_CONSTANT_Utf8_info), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_CONSTANT_Utf8_info
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_CONSTANT_Utf8_info (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_CONSTANT_Utf8_info ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_CONSTANT_Utf8_info), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_Code_attribute
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_Code_attribute (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_Code_attribute ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_Code_attribute), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_Code_attribute
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_Code_attribute (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_Code_attribute ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_Code_attribute), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_ConstantValue_attribute
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_ConstantValue_attribute (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_ConstantValue_attribute ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_ConstantValue_attribute), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_ConstantValue_attribute
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_ConstantValue_attribute (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_ConstantValue_attribute ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_ConstantValue_attribute), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_Deprecated_attribute
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_Deprecated_attribute (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_Deprecated_attribute ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_Deprecated_attribute), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_Deprecated_attribute
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_Deprecated_attribute (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_Deprecated_attribute ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_Deprecated_attribute), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_Exceptions_attribute
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_Exceptions_attribute (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_Exceptions_attribute ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_Exceptions_attribute), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_Exceptions_attribute
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_Exceptions_attribute (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_Exceptions_attribute ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_Exceptions_attribute), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_InnerClasses_attribute
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_InnerClasses_attribute (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_InnerClasses_attribute ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_InnerClasses_attribute), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_InnerClasses_attribute
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_InnerClasses_attribute (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_InnerClasses_attribute ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_InnerClasses_attribute), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_LineNumberTable_attribute
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_LineNumberTable_attribute (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_LineNumberTable_attribute ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_LineNumberTable_attribute), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_LineNumberTable_attribute
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_LineNumberTable_attribute (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_LineNumberTable_attribute ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_LineNumberTable_attribute), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_LocalVariableTable_attribute
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_LocalVariableTable_attribute (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_LocalVariableTable_attribute ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_LocalVariableTable_attribute), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_LocalVariableTable_attribute
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_LocalVariableTable_attribute (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_LocalVariableTable_attribute ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_LocalVariableTable_attribute), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_SourceFile_attribute
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_SourceFile_attribute (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_SourceFile_attribute ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_SourceFile_attribute), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_SourceFile_attribute
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_SourceFile_attribute (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_SourceFile_attribute ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_SourceFile_attribute), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_Synthetic_attribute
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_Synthetic_attribute (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_Synthetic_attribute ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_Synthetic_attribute), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_Synthetic_attribute
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_Synthetic_attribute (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_Synthetic_attribute ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_Synthetic_attribute), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_array_info
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_array_info (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_array_info ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_array_info), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_array_info
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_array_info (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_array_info ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_array_info), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_class_info
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_class_info (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_class_info ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_class_info), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_class_info
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_class_info (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_class_info ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_class_info), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_native_cif
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_native_cif (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, ffi_cif ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (ffi_cif), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_native_cif
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_native_cif (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, ffi_cif ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (ffi_cif), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_native_library
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_native_library (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_native_library ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_native_library), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_native_library
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_native_library (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_native_library ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_native_library), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_native_method_data
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_native_method_data (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_native_method_data ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_native_method_data), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_native_method_data
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_native_method_data (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_native_method_data ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_native_method_data), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zalloc_unknown_attribute
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zalloc_unknown_attribute (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, _svmt_unknown_attribute ** ptr)
{
  return _svmf_cl_zalloc (env, class_loader_info, sizeof (_svmt_unknown_attribute), (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zfree_unknown_attribute
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zfree_unknown_attribute (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, _svmt_unknown_attribute ** ptr)
{
  _svmf_cl_free (env, class_loader_info, sizeof (_svmt_unknown_attribute), (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_malloc_attributes
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_malloc_attributes (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info,
		    size_t nmemb, _svmt_attribute_info * ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_attribute_info *);

  /* check for overflow */
  if (size < nmemb)
    {
      _svmf_error_OutOfMemoryError (env);
      return JNI_ERR;
    }

  return _svmf_cl_alloc (env, class_loader_info, size, (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_mfree_attributes
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_mfree_attributes (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, size_t nmemb,
		   _svmt_attribute_info * ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_attribute_info *);

  _svmf_cl_free (env, class_loader_info, size, (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_malloc_chars
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_malloc_chars (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info,
		    size_t nmemb, char ** ptr)
{
  size_t size = nmemb * sizeof (char);

  /* check for overflow */
  if (size < nmemb)
    {
      _svmf_error_OutOfMemoryError (env);
      return JNI_ERR;
    }

  return _svmf_cl_alloc (env, class_loader_info, size, (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_mfree_chars
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_mfree_chars (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, size_t nmemb,
		   char ** ptr)
{
  size_t size = nmemb * sizeof (char);

  _svmf_cl_free (env, class_loader_info, size, (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_malloc_classes
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_malloc_classes (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info,
		    size_t nmemb, _svmt_CONSTANT_Class_info ** ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_CONSTANT_Class_info **);

  /* check for overflow */
  if (size < nmemb)
    {
      _svmf_error_OutOfMemoryError (env);
      return JNI_ERR;
    }

  return _svmf_cl_alloc (env, class_loader_info, size, (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_mfree_classes
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_mfree_classes (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, size_t nmemb,
		   _svmt_CONSTANT_Class_info ** ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_CONSTANT_Class_info **);

  _svmf_cl_free (env, class_loader_info, size, (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_malloc_constant_pool
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_malloc_constant_pool (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info,
		    size_t nmemb, _svmt_cp_info * ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_cp_info *);

  /* check for overflow */
  if (size < nmemb)
    {
      _svmf_error_OutOfMemoryError (env);
      return JNI_ERR;
    }

  return _svmf_cl_alloc (env, class_loader_info, size, (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_mfree_constant_pool
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_mfree_constant_pool (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, size_t nmemb,
		   _svmt_cp_info * ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_cp_info *);

  _svmf_cl_free (env, class_loader_info, size, (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_malloc_inner_classes
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_malloc_inner_classes (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info,
		    size_t nmemb, _svmt_inner_classes ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_inner_classes);

  /* check for overflow */
  if (size < nmemb)
    {
      _svmf_error_OutOfMemoryError (env);
      return JNI_ERR;
    }

  return _svmf_cl_alloc (env, class_loader_info, size, (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_mfree_inner_classes
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_mfree_inner_classes (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, size_t nmemb,
		   _svmt_inner_classes ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_inner_classes);

  _svmf_cl_free (env, class_loader_info, size, (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_malloc_native_arg_types
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_malloc_native_arg_types (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info,
		    size_t nmemb, jint ** ptr)
{
  size_t size = nmemb * sizeof (jint);

  /* check for overflow */
  if (size < nmemb)
    {
      _svmf_error_OutOfMemoryError (env);
      return JNI_ERR;
    }

  return _svmf_cl_alloc (env, class_loader_info, size, (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_mfree_native_arg_types
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_mfree_native_arg_types (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, size_t nmemb,
		   jint ** ptr)
{
  size_t size = nmemb * sizeof (jint);

  _svmf_cl_free (env, class_loader_info, size, (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_malloc_native_args
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_malloc_native_args (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info,
		    size_t nmemb, ffi_type * ** ptr)
{
  size_t size = nmemb * sizeof (ffi_type *);

  /* check for overflow */
  if (size < nmemb)
    {
      _svmf_error_OutOfMemoryError (env);
      return JNI_ERR;
    }

  return _svmf_cl_alloc (env, class_loader_info, size, (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_mfree_native_args
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_mfree_native_args (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, size_t nmemb,
		   ffi_type * ** ptr)
{
  size_t size = nmemb * sizeof (ffi_type *);

  _svmf_cl_free (env, class_loader_info, size, (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_malloc_super_classes
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_malloc_super_classes (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info,
		    size_t nmemb, _svmt_class_info * ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_class_info *);

  /* check for overflow */
  if (size < nmemb)
    {
      _svmf_error_OutOfMemoryError (env);
      return JNI_ERR;
    }

  return _svmf_cl_alloc (env, class_loader_info, size, (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_mfree_super_classes
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_mfree_super_classes (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, size_t nmemb,
		   _svmt_class_info * ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_class_info *);

  _svmf_cl_free (env, class_loader_info, size, (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_malloc_u8
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_malloc_u8 (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info,
		    size_t nmemb, _svmt_u8 ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_u8);

  /* check for overflow */
  if (size < nmemb)
    {
      _svmf_error_OutOfMemoryError (env);
      return JNI_ERR;
    }

  return _svmf_cl_alloc (env, class_loader_info, size, (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_mfree_u8
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_mfree_u8 (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, size_t nmemb,
		   _svmt_u8 ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_u8);

  _svmf_cl_free (env, class_loader_info, size, (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_malloc_code
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_malloc_code (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info,
		    size_t nmemb, _svmt_code ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_code);

  /* check for overflow */
  if (size < nmemb)
    {
      _svmf_error_OutOfMemoryError (env);
      return JNI_ERR;
    }

  return _svmf_cl_alloc (env, class_loader_info, size, (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_mfree_code
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_mfree_code (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, size_t nmemb,
		   _svmt_code ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_code);

  _svmf_cl_free (env, class_loader_info, size, (void **) ptr);
}


#if defined (_SABLEVM_TRADITIONAL_OBJECT_LAYOUT)

/*
----------------------------------------------------------------------
_svmh_cl_malloc_size_t
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_malloc_size_t (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info,
		    size_t nmemb, size_t ** ptr)
{
  size_t size = nmemb * sizeof (size_t);

  /* check for overflow */
  if (size < nmemb)
    {
      _svmf_error_OutOfMemoryError (env);
      return JNI_ERR;
    }

  return _svmf_cl_alloc (env, class_loader_info, size, (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_mfree_size_t
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_mfree_size_t (_svmt_JNIEnv *env,
		   _svmt_class_loader_info *class_loader_info, size_t nmemb,
		   size_t ** ptr)
{
  size_t size = nmemb * sizeof (size_t);

  _svmf_cl_free (env, class_loader_info, size, (void **) ptr);
}


#endif /* _SABLEVM_TRADITIONAL_OBJECT_LAYOUT */

/*
----------------------------------------------------------------------
_svmh_cl_zmalloc_fields
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zmalloc_fields (_svmt_JNIEnv *env,
		     _svmt_class_loader_info *class_loader_info, size_t nmemb,
		     _svmt_field_info ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_field_info);

  /* check for overflow */
  if (size < nmemb)
    {
      _svmf_error_OutOfMemoryError (env);
      return JNI_ERR;
    }

  return _svmf_cl_zalloc (env, class_loader_info, size, (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zmfree_fields
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zmfree_fields (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, size_t nmemb,
		    _svmt_field_info ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_field_info);

  _svmf_cl_free (env, class_loader_info, size, (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zmalloc_methods
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zmalloc_methods (_svmt_JNIEnv *env,
		     _svmt_class_loader_info *class_loader_info, size_t nmemb,
		     _svmt_method_info ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_method_info);

  /* check for overflow */
  if (size < nmemb)
    {
      _svmf_error_OutOfMemoryError (env);
      return JNI_ERR;
    }

  return _svmf_cl_zalloc (env, class_loader_info, size, (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zmfree_methods
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zmfree_methods (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, size_t nmemb,
		    _svmt_method_info ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_method_info);

  _svmf_cl_free (env, class_loader_info, size, (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zmalloc_exception_table
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zmalloc_exception_table (_svmt_JNIEnv *env,
		     _svmt_class_loader_info *class_loader_info, size_t nmemb,
		     _svmt_exception_table ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_exception_table);

  /* check for overflow */
  if (size < nmemb)
    {
      _svmf_error_OutOfMemoryError (env);
      return JNI_ERR;
    }

  return _svmf_cl_zalloc (env, class_loader_info, size, (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zmfree_exception_table
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zmfree_exception_table (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, size_t nmemb,
		    _svmt_exception_table ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_exception_table);

  _svmf_cl_free (env, class_loader_info, size, (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zmalloc_line_number_table
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zmalloc_line_number_table (_svmt_JNIEnv *env,
		     _svmt_class_loader_info *class_loader_info, size_t nmemb,
		     _svmt_line_number_table ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_line_number_table);

  /* check for overflow */
  if (size < nmemb)
    {
      _svmf_error_OutOfMemoryError (env);
      return JNI_ERR;
    }

  return _svmf_cl_zalloc (env, class_loader_info, size, (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zmfree_line_number_table
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zmfree_line_number_table (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, size_t nmemb,
		    _svmt_line_number_table ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_line_number_table);

  _svmf_cl_free (env, class_loader_info, size, (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zmalloc_local_variable_table
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zmalloc_local_variable_table (_svmt_JNIEnv *env,
		     _svmt_class_loader_info *class_loader_info, size_t nmemb,
		     _svmt_local_variable_table ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_local_variable_table);

  /* check for overflow */
  if (size < nmemb)
    {
      _svmf_error_OutOfMemoryError (env);
      return JNI_ERR;
    }

  return _svmf_cl_zalloc (env, class_loader_info, size, (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zmfree_local_variable_table
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zmfree_local_variable_table (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, size_t nmemb,
		    _svmt_local_variable_table ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_local_variable_table);

  _svmf_cl_free (env, class_loader_info, size, (void **) ptr);
}


/*
----------------------------------------------------------------------
_svmh_cl_zmalloc_super_interfaces
----------------------------------------------------------------------
*/

svm_static jint
_svmh_cl_zmalloc_super_interfaces (_svmt_JNIEnv *env,
		     _svmt_class_loader_info *class_loader_info, size_t nmemb,
		     _svmt_u8 ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_u8);

  /* check for overflow */
  if (size < nmemb)
    {
      _svmf_error_OutOfMemoryError (env);
      return JNI_ERR;
    }

  return _svmf_cl_zalloc (env, class_loader_info, size, (void **) ptr);
}

/*
----------------------------------------------------------------------
_svmh_cl_zmfree_super_interfaces
----------------------------------------------------------------------
*/

svm_static void SVM_UNUSED
_svmh_cl_zmfree_super_interfaces (_svmt_JNIEnv *env,
		    _svmt_class_loader_info *class_loader_info, size_t nmemb,
		    _svmt_u8 ** ptr)
{
  size_t size = nmemb * sizeof (_svmt_u8);

  _svmf_cl_free (env, class_loader_info, size, (void **) ptr);
}

