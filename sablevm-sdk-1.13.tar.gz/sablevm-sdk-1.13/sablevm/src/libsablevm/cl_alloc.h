/* This file has been automatically generated from "cl_alloc.list" */

#ifndef SVM_CL_ALLOC_H
#define SVM_CL_ALLOC_H

/*
----------------------------------------------------------------------
_svmm_cl_zalloc_CONSTANT_Class_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_CONSTANT_Class_info(env, cli, ptr) \
_svmh_cl_zalloc_CONSTANT_Class_info (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_CONSTANT_Class_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_CONSTANT_Class_info(cli, ptr) \
_svmh_cl_zfree_CONSTANT_Class_info (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_CONSTANT_Double_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_CONSTANT_Double_info(env, cli, ptr) \
_svmh_cl_zalloc_CONSTANT_Double_info (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_CONSTANT_Double_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_CONSTANT_Double_info(cli, ptr) \
_svmh_cl_zfree_CONSTANT_Double_info (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_CONSTANT_Fieldref_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_CONSTANT_Fieldref_info(env, cli, ptr) \
_svmh_cl_zalloc_CONSTANT_Fieldref_info (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_CONSTANT_Fieldref_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_CONSTANT_Fieldref_info(cli, ptr) \
_svmh_cl_zfree_CONSTANT_Fieldref_info (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_CONSTANT_Float_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_CONSTANT_Float_info(env, cli, ptr) \
_svmh_cl_zalloc_CONSTANT_Float_info (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_CONSTANT_Float_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_CONSTANT_Float_info(cli, ptr) \
_svmh_cl_zfree_CONSTANT_Float_info (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_CONSTANT_Integer_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_CONSTANT_Integer_info(env, cli, ptr) \
_svmh_cl_zalloc_CONSTANT_Integer_info (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_CONSTANT_Integer_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_CONSTANT_Integer_info(cli, ptr) \
_svmh_cl_zfree_CONSTANT_Integer_info (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_CONSTANT_InterfaceMethodref_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_CONSTANT_InterfaceMethodref_info(env, cli, ptr) \
_svmh_cl_zalloc_CONSTANT_InterfaceMethodref_info (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_CONSTANT_InterfaceMethodref_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_CONSTANT_InterfaceMethodref_info(cli, ptr) \
_svmh_cl_zfree_CONSTANT_InterfaceMethodref_info (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_CONSTANT_Long_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_CONSTANT_Long_info(env, cli, ptr) \
_svmh_cl_zalloc_CONSTANT_Long_info (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_CONSTANT_Long_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_CONSTANT_Long_info(cli, ptr) \
_svmh_cl_zfree_CONSTANT_Long_info (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_CONSTANT_Methodref_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_CONSTANT_Methodref_info(env, cli, ptr) \
_svmh_cl_zalloc_CONSTANT_Methodref_info (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_CONSTANT_Methodref_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_CONSTANT_Methodref_info(cli, ptr) \
_svmh_cl_zfree_CONSTANT_Methodref_info (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_CONSTANT_NameAndType_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_CONSTANT_NameAndType_info(env, cli, ptr) \
_svmh_cl_zalloc_CONSTANT_NameAndType_info (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_CONSTANT_NameAndType_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_CONSTANT_NameAndType_info(cli, ptr) \
_svmh_cl_zfree_CONSTANT_NameAndType_info (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_CONSTANT_String_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_CONSTANT_String_info(env, cli, ptr) \
_svmh_cl_zalloc_CONSTANT_String_info (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_CONSTANT_String_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_CONSTANT_String_info(cli, ptr) \
_svmh_cl_zfree_CONSTANT_String_info (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_CONSTANT_Utf8_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_CONSTANT_Utf8_info(env, cli, ptr) \
_svmh_cl_zalloc_CONSTANT_Utf8_info (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_CONSTANT_Utf8_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_CONSTANT_Utf8_info(cli, ptr) \
_svmh_cl_zfree_CONSTANT_Utf8_info (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_Code_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_Code_attribute(env, cli, ptr) \
_svmh_cl_zalloc_Code_attribute (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_Code_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_Code_attribute(cli, ptr) \
_svmh_cl_zfree_Code_attribute (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_ConstantValue_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_ConstantValue_attribute(env, cli, ptr) \
_svmh_cl_zalloc_ConstantValue_attribute (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_ConstantValue_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_ConstantValue_attribute(cli, ptr) \
_svmh_cl_zfree_ConstantValue_attribute (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_Deprecated_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_Deprecated_attribute(env, cli, ptr) \
_svmh_cl_zalloc_Deprecated_attribute (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_Deprecated_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_Deprecated_attribute(cli, ptr) \
_svmh_cl_zfree_Deprecated_attribute (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_Exceptions_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_Exceptions_attribute(env, cli, ptr) \
_svmh_cl_zalloc_Exceptions_attribute (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_Exceptions_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_Exceptions_attribute(cli, ptr) \
_svmh_cl_zfree_Exceptions_attribute (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_InnerClasses_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_InnerClasses_attribute(env, cli, ptr) \
_svmh_cl_zalloc_InnerClasses_attribute (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_InnerClasses_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_InnerClasses_attribute(cli, ptr) \
_svmh_cl_zfree_InnerClasses_attribute (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_LineNumberTable_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_LineNumberTable_attribute(env, cli, ptr) \
_svmh_cl_zalloc_LineNumberTable_attribute (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_LineNumberTable_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_LineNumberTable_attribute(cli, ptr) \
_svmh_cl_zfree_LineNumberTable_attribute (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_LocalVariableTable_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_LocalVariableTable_attribute(env, cli, ptr) \
_svmh_cl_zalloc_LocalVariableTable_attribute (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_LocalVariableTable_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_LocalVariableTable_attribute(cli, ptr) \
_svmh_cl_zfree_LocalVariableTable_attribute (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_SourceFile_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_SourceFile_attribute(env, cli, ptr) \
_svmh_cl_zalloc_SourceFile_attribute (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_SourceFile_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_SourceFile_attribute(cli, ptr) \
_svmh_cl_zfree_SourceFile_attribute (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_Synthetic_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_Synthetic_attribute(env, cli, ptr) \
_svmh_cl_zalloc_Synthetic_attribute (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_Synthetic_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_Synthetic_attribute(cli, ptr) \
_svmh_cl_zfree_Synthetic_attribute (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_array_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_array_info(env, cli, ptr) \
_svmh_cl_zalloc_array_info (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_array_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_array_info(cli, ptr) \
_svmh_cl_zfree_array_info (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_class_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_class_info(env, cli, ptr) \
_svmh_cl_zalloc_class_info (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_class_info
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_class_info(cli, ptr) \
_svmh_cl_zfree_class_info (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_native_cif
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_native_cif(env, cli, ptr) \
_svmh_cl_zalloc_native_cif (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_native_cif
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_native_cif(cli, ptr) \
_svmh_cl_zfree_native_cif (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_native_library
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_native_library(env, cli, ptr) \
_svmh_cl_zalloc_native_library (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_native_library
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_native_library(cli, ptr) \
_svmh_cl_zfree_native_library (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_native_method_data
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_native_method_data(env, cli, ptr) \
_svmh_cl_zalloc_native_method_data (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_native_method_data
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_native_method_data(cli, ptr) \
_svmh_cl_zfree_native_method_data (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zalloc_unknown_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zalloc_unknown_attribute(env, cli, ptr) \
_svmh_cl_zalloc_unknown_attribute (env, cli, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zfree_unknown_attribute
----------------------------------------------------------------------
*/

#define _svmm_cl_zfree_unknown_attribute(cli, ptr) \
_svmh_cl_zfree_unknown_attribute (cli, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_malloc_attributes
----------------------------------------------------------------------
*/

#define _svmm_cl_malloc_attributes(env, cli, n, ptr) \
_svmh_cl_malloc_attributes (env, cli, n, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_mfree_attributes
----------------------------------------------------------------------
*/

#define _svmm_cl_mfree_attributes(cli, n, ptr) \
_svmh_cl_mfree_attributes (cli, n, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_malloc_chars
----------------------------------------------------------------------
*/

#define _svmm_cl_malloc_chars(env, cli, n, ptr) \
_svmh_cl_malloc_chars (env, cli, n, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_mfree_chars
----------------------------------------------------------------------
*/

#define _svmm_cl_mfree_chars(cli, n, ptr) \
_svmh_cl_mfree_chars (cli, n, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_malloc_classes
----------------------------------------------------------------------
*/

#define _svmm_cl_malloc_classes(env, cli, n, ptr) \
_svmh_cl_malloc_classes (env, cli, n, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_mfree_classes
----------------------------------------------------------------------
*/

#define _svmm_cl_mfree_classes(cli, n, ptr) \
_svmh_cl_mfree_classes (cli, n, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_malloc_constant_pool
----------------------------------------------------------------------
*/

#define _svmm_cl_malloc_constant_pool(env, cli, n, ptr) \
_svmh_cl_malloc_constant_pool (env, cli, n, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_mfree_constant_pool
----------------------------------------------------------------------
*/

#define _svmm_cl_mfree_constant_pool(cli, n, ptr) \
_svmh_cl_mfree_constant_pool (cli, n, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_malloc_inner_classes
----------------------------------------------------------------------
*/

#define _svmm_cl_malloc_inner_classes(env, cli, n, ptr) \
_svmh_cl_malloc_inner_classes (env, cli, n, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_mfree_inner_classes
----------------------------------------------------------------------
*/

#define _svmm_cl_mfree_inner_classes(cli, n, ptr) \
_svmh_cl_mfree_inner_classes (cli, n, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_malloc_native_arg_types
----------------------------------------------------------------------
*/

#define _svmm_cl_malloc_native_arg_types(env, cli, n, ptr) \
_svmh_cl_malloc_native_arg_types (env, cli, n, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_mfree_native_arg_types
----------------------------------------------------------------------
*/

#define _svmm_cl_mfree_native_arg_types(cli, n, ptr) \
_svmh_cl_mfree_native_arg_types (cli, n, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_malloc_native_args
----------------------------------------------------------------------
*/

#define _svmm_cl_malloc_native_args(env, cli, n, ptr) \
_svmh_cl_malloc_native_args (env, cli, n, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_mfree_native_args
----------------------------------------------------------------------
*/

#define _svmm_cl_mfree_native_args(cli, n, ptr) \
_svmh_cl_mfree_native_args (cli, n, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_malloc_super_classes
----------------------------------------------------------------------
*/

#define _svmm_cl_malloc_super_classes(env, cli, n, ptr) \
_svmh_cl_malloc_super_classes (env, cli, n, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_mfree_super_classes
----------------------------------------------------------------------
*/

#define _svmm_cl_mfree_super_classes(cli, n, ptr) \
_svmh_cl_mfree_super_classes (cli, n, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_malloc_u8
----------------------------------------------------------------------
*/

#define _svmm_cl_malloc_u8(env, cli, n, ptr) \
_svmh_cl_malloc_u8 (env, cli, n, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_mfree_u8
----------------------------------------------------------------------
*/

#define _svmm_cl_mfree_u8(cli, n, ptr) \
_svmh_cl_mfree_u8 (cli, n, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_malloc_code
----------------------------------------------------------------------
*/

#define _svmm_cl_malloc_code(env, cli, n, ptr) \
_svmh_cl_malloc_code (env, cli, n, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_mfree_code
----------------------------------------------------------------------
*/

#define _svmm_cl_mfree_code(cli, n, ptr) \
_svmh_cl_mfree_code (cli, n, &ptr)


#if defined (_SABLEVM_TRADITIONAL_OBJECT_LAYOUT)

/*
----------------------------------------------------------------------
_svmm_cl_malloc_size_t
----------------------------------------------------------------------
*/

#define _svmm_cl_malloc_size_t(env, cli, n, ptr) \
_svmh_cl_malloc_size_t (env, cli, n, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_mfree_size_t
----------------------------------------------------------------------
*/

#define _svmm_cl_mfree_size_t(cli, n, ptr) \
_svmh_cl_mfree_size_t (cli, n, &ptr)


#endif /* _SABLEVM_TRADITIONAL_OBJECT_LAYOUT */

/*
----------------------------------------------------------------------
_svmm_cl_zmalloc_fields
----------------------------------------------------------------------
*/

#define _svmm_cl_zmalloc_fields(env, cli, n, ptr) \
_svmh_cl_zmalloc_fields (env, cli, n, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zmfree_fields
----------------------------------------------------------------------
*/

#define _svmm_cl_zmfree_fields(cli, n, ptr) \
_svmh_cl_zmfree_fields (cli, n, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zmalloc_methods
----------------------------------------------------------------------
*/

#define _svmm_cl_zmalloc_methods(env, cli, n, ptr) \
_svmh_cl_zmalloc_methods (env, cli, n, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zmfree_methods
----------------------------------------------------------------------
*/

#define _svmm_cl_zmfree_methods(cli, n, ptr) \
_svmh_cl_zmfree_methods (cli, n, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zmalloc_exception_table
----------------------------------------------------------------------
*/

#define _svmm_cl_zmalloc_exception_table(env, cli, n, ptr) \
_svmh_cl_zmalloc_exception_table (env, cli, n, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zmfree_exception_table
----------------------------------------------------------------------
*/

#define _svmm_cl_zmfree_exception_table(cli, n, ptr) \
_svmh_cl_zmfree_exception_table (cli, n, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zmalloc_line_number_table
----------------------------------------------------------------------
*/

#define _svmm_cl_zmalloc_line_number_table(env, cli, n, ptr) \
_svmh_cl_zmalloc_line_number_table (env, cli, n, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zmfree_line_number_table
----------------------------------------------------------------------
*/

#define _svmm_cl_zmfree_line_number_table(cli, n, ptr) \
_svmh_cl_zmfree_line_number_table (cli, n, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zmalloc_local_variable_table
----------------------------------------------------------------------
*/

#define _svmm_cl_zmalloc_local_variable_table(env, cli, n, ptr) \
_svmh_cl_zmalloc_local_variable_table (env, cli, n, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zmfree_local_variable_table
----------------------------------------------------------------------
*/

#define _svmm_cl_zmfree_local_variable_table(cli, n, ptr) \
_svmh_cl_zmfree_local_variable_table (cli, n, &ptr)


/*
----------------------------------------------------------------------
_svmm_cl_zmalloc_super_interfaces
----------------------------------------------------------------------
*/

#define _svmm_cl_zmalloc_super_interfaces(env, cli, n, ptr) \
_svmh_cl_zmalloc_super_interfaces (env, cli, n, &ptr)

/*
----------------------------------------------------------------------
_svmm_cl_zmfree_super_interfaces
----------------------------------------------------------------------
*/

#define _svmm_cl_zmfree_super_interfaces(cli, n, ptr) \
_svmh_cl_zmfree_super_interfaces (cli, n, &ptr)


#endif /* NOT SVM_CL_ALLOC_H */
